1. What is encapsulation?
Encapsulation is the process of wrapping data (fields) and methods (functions) together into a single unit (class) and restricting direct access to data by using access modifiers (private, public, etc.).


2. How are ArrayLists different from arrays?
An Array in Java is a fixed-size data structure that stores elements of the same type. Once created, its size cannot be changed. It can store both primitive types (like int, char) and objects
An ArrayList is a resizable collection class in Java that is part of the java.util package. It can grow or shrink dynamically as elements are added or removed. However, it can only store objects (for primitives, wrapper classes like Integer, Double are used)

3. How to sort an ArrayList?
Use Collections.sort() method:


4. What is constructor overloading?
Constructor overloading means having multiple constructors in a class with different parameter lists so objects can be created in different ways.


5. How does garbage collection work in Java?
Garbage Collection (GC) automatically removes unused objects from memory to free space.
Java checks which objects are no longer referenced and deletes them.
Done by JVM using algorithms like Mark and Sweep.
Triggered automatically, but can request with System.gc().


6. Why do we use getters and setters?
To control access to private fields.
Allow validation before setting values.
Maintain encapsulation.


7. What is a static variable?
A variable shared among all objects of a class.
Belongs to the class, not to a specific object.
Declared using static keyword.


8. What is the use of final keyword?
final variable → Value can’t be changed (constant).
final method → Can’t be overridden.
final class → Can’t be inherited.


9. Difference between compile-time and runtime errors?
Compile-time Errors	Runtime Errors
Found by compiler before execution.	Occur while program is running.
Syntax errors, missing semicolon.	NullPointerException, ArrayIndexOutOfBoundsException.

10. What are access modifiers?
Access modifiers define visibility of variables, methods, and classes.

public → Accessible everywhere.

protected → Accessible in same package & subclasses.

(default) → Accessible in same package only.

private → Accessible only within the class.